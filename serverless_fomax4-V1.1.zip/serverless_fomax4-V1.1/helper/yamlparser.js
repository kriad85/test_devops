#!/usr/bin/env node
const fs = require('fs');
const YAML = require('js-yaml');

module.exports = function (confpath) {
  //console.log(confpath);
  const configs = YAML.safeLoad(fs.readFileSync(confpath, 'utf8'));
  //console.log(configs);
  return configs;
}
