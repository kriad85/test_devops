const parse = require('../templates/parser.js');
const fs = require('fs');
const YAML = require('js-yaml');
const loadYaml = require('../templates/yamlparser.js')

module.exports = (ec2) => {
  const confpath = ((__dirname) + "/../conf/" + "/ec2.yml");
  //console.log(confpath1 + confpath2);
  let resources = 'Resources: \n';

  if (fs.existsSync(confpath)) {
    const configs = loadYaml(confpath);
    //console.log(configs);
    resources += parse(['ec2'], configs);
	console.log('returned from parse');
    finalfile = resources;
	//console.log(finalfile);
  }
  else{
    console.log('Warning: No Topic To generate\n');
    return '';
  }
  //console.log(finalfile);
  return YAML.load(finalfile);
}; 