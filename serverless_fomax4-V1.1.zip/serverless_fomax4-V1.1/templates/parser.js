const fs = require('fs');
const YAML = require('js-yaml');

module.exports = (tpls, configs) => {
  let finalDef = ''; 
  tpls.forEach((tpl) => {
    const tplPath = `${__dirname}/${tpl}.tpl.yml`;
    const tplContent = fs.readFileSync(tplPath).toString();
    console.log('KRI entered in parser.js');
	console.log('tpls:'+ tpls);
	console.log('configs:'+ configs);
    configs.forEach((configItem) => {
      console.log('configs:'+configItem.instancename);
      let def = tplContent.replace('Resources:', '');
	  //console.log(def);
      // add a custom field
      configItem.TplVersion = tpl;
      console.log('configItem.TplVersion:'+configItem.TplVersion);
      for(opt in configItem) {
        if(configItem.hasOwnProperty(opt)) {
          //console.log(opt);
          const re = new RegExp('@' + opt + '@', 'g');
          def= def.replace(re, configItem[opt]) + "\n";
        }
      }
      finalDef+= def;
    });
  });
  console.log(finalDef);
  return finalDef
}
